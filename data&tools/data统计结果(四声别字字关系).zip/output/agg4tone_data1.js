var data1=[
[undefined,undefined,undefined,undefined,undefined,],
[undefined,35173,39192,25139,68587,],
[undefined,22107,22379,28097,49688,],
[undefined,20249,25640,20808,42400,],
[undefined,33583,41836,44839,102955,],
];
