var data2=[
[undefined,undefined,undefined,undefined,undefined,],
[undefined,28936,24000,22273,44147,],
[undefined,32099,24836,23537,50253,],
[undefined,33326,23954,23533,49711,],
[undefined,74730,52880,52731,114191,],
];
